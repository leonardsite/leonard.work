# Frontend Skills

| # | Skill | Topics |
|---|-------|--------|
| 1 | **react** | React 18+, hooks, server components, RSC |
| 2 | **vue** | Vue 3, Composition API, Pinia |
| 3 | **nextjs** | Next.js 14+, App Router, RSC |
| 4 | **tailwind** | Tailwind CSS v4, design tokens |
| 5 | **typescript** | Advanced TS patterns |
| 6 | **svelte** | SvelteKit, runes |
| 7 | **css** | Modern CSS, container queries, layers |

Usage: `/hub it frontend <skill>`
