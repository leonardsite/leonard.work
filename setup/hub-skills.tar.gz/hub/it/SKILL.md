# IT Skills

| # | Subcategory | Topics |
|---|------------|--------|
| 1 | **frontend** | React, Vue, Angular, Svelte, Next.js, Tailwind, TypeScript, CSS |
| 2 | **backend** | Rust, Python (LangChain/LangGraph/LangSmith/Deep Agents), Node.js, Go, Java |
| 3 | **devops** | Docker, Kubernetes, Terraform, CI/CD, GitHub Actions |
| 4 | **mobile** | React Native, Flutter, iOS (Swift), Android (Kotlin), Expo |
| 5 | **databases** | PostgreSQL, MySQL, MongoDB, Redis, SQLite, Supabase |
| 6 | **cloud** | AWS, GCP, Azure, Cloudflare Workers, Vercel, Netlify |
| 7 | **testing** | Jest, Pytest, Playwright, Cypress, E2E, Performance |
| 8 | **ai-ml** | Framework selection, MLOps, LLM, Vector DBs, HuggingFace |

Usage: `/hub it <subcategory>`
