# AI/ML Skills

| # | Skill | Topics |
|---|-------|--------|
| 1 | **framework-selection** | LangChain vs LangGraph vs Deep Agents 选型 |
| 2 | **huggingface** | Models, datasets, training, evaluation |
| 3 | **vector-dbs** | Chroma, FAISS, Pinecone, pgvector |
| 4 | **mlops** | MLflow, model serving, monitoring |

Usage: `/hub it ai-ml <skill>`
