# Python Backend Skills

| # | Skill | Sub-skills |
|---|-------|-----------|
| 1 | **langchain** | fundamentals, middleware, rag, dependencies |
| 2 | **langgraph** | fundamentals, human-in-the-loop, persistence |
| 3 | **langsmith** | dataset, evaluator, trace |
| 4 | **deep-agents** | core, memory, orchestration |

Usage: `/hub it backend python <skill>`
