# Backend Skills

| # | Skill | Topics |
|---|-------|--------|
| 1 | **rust** | Rust 2024, Axum, CLI, gRPC, concurrency, database, errors, config, observability (18 sub-skills) |
| 2 | **python** | LangChain, LangGraph, LangSmith, Deep Agents |
| 3 | **nodejs** | Express, Fastify, NestJS |
| 4 | **go** | Go patterns, concurrency |
| 5 | **java** | Spring Boot, Quarkus |

Usage: `/hub it backend <skill>`
