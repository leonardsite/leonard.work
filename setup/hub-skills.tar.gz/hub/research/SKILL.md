# Research Skills

| # | Subcategory | Topics |
|---|------------|--------|
| 1 | **academic** | Literature review, citations, LaTeX |
| 2 | **data-science** | Pandas, NumPy, visualization, statistics |
| 3 | **ml** | Scikit-learn, PyTorch, TensorFlow |
| 4 | **nlp** | Text processing, sentiment, NER, transformers, RAG |
| 5 | **llm** | Prompt engineering, fine-tuning, evaluation, agents |

Usage: `/hub research <subcategory>`
