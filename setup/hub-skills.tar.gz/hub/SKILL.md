---
description: "Skill hub — /hub to browse 450+ skills. /hub <domain> to drill down. Domains: it, design, finance, marketing, security, research, productivity, ops."
---

# Skill Hub

Parse $ARGUMENTS to navigate the skill hierarchy.

## Routing

1. No args → Read `~/.claude/skills/hub/INDEX.md`, display category table
2. One word (e.g. "it") → Read `~/.claude/skills/hub/<arg>/SKILL.md`
3. Two words (e.g. "it backend") → Read `~/.claude/skills/hub/<arg1>/<arg2>/SKILL.md`
4. Three+ words (e.g. "it backend rust axum") → Read deepest matching path
5. Path not found → suggest closest from INDEX.md

## Shortcuts

| Alias | Target |
|-------|--------|
| rust | it/backend/rust |
| langchain | it/backend/python/langchain |
| langgraph | it/backend/python/langgraph |
| langsmith | it/backend/python/langsmith |
| deep-agents | it/backend/python/deep-agents |
| react | it/frontend/react |
| sign | ops/signing |
| cf | ops/cloudflare |
| git | productivity/git |
| docs | productivity/docs |

## Execution

When you reach a leaf SKILL.md, read it fully and **execute** its instructions. Do not summarize.
