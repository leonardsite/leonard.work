# Finance Skills

| # | Subcategory | Topics |
|---|------------|--------|
| 1 | **fintech** | Payments, Stripe, banking APIs |
| 2 | **crypto** | Solidity, Web3, DeFi, smart contracts |
| 3 | **trading** | Algorithmic trading, backtesting, market data |
| 4 | **compliance** | AML, KYC, SOX, regulatory |

Usage: `/hub finance <subcategory>`
