# Skill Hub Index

| # | Domain | Subcategories | Skills |
|---|--------|--------------|--------|
| 1 | **it** | frontend, backend, devops, mobile, databases, cloud, testing, ai-ml | 180+ |
| 2 | **design** | ux, ui, graphic, brand, motion | 35+ |
| 3 | **finance** | fintech, crypto, trading, compliance | 40+ |
| 4 | **marketing** | seo, content, analytics, ads, growth | 45+ |
| 5 | **security** | appsec, pentest, cloud-sec, grc, devsecops | 50+ |
| 6 | **research** | academic, data-science, ml, nlp, llm | 35+ |
| 7 | **productivity** | git, docs, project-mgmt, automation, writing, cli | 60+ |
| 8 | **ops** | signing, cloudflare, mcp, infra | 15+ |

Usage: `/hub <domain>` → `/hub <domain> <subcategory>` → `/hub <domain> <subcategory> <skill>`
Shortcuts: `/hub rust`, `/hub langchain`, `/hub react`, `/hub sign`, `/hub git`
