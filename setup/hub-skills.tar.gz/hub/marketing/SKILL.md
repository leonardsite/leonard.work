# Marketing Skills

| # | Subcategory | Topics |
|---|------------|--------|
| 1 | **seo** | Technical SEO, content SEO, schema markup |
| 2 | **content** | Copywriting, blogging, newsletters |
| 3 | **analytics** | Google Analytics, Mixpanel, attribution |
| 4 | **ads** | Google Ads, Meta Ads, programmatic |
| 5 | **growth** | A/B testing, CRO, product-led growth |

Usage: `/hub marketing <subcategory>`
