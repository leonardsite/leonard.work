# Design Skills

| # | Subcategory | Topics |
|---|------------|--------|
| 1 | **ux** | User research, wireframing, accessibility, information architecture |
| 2 | **ui** | Design systems, component libraries, Figma, Storybook |
| 3 | **graphic** | Illustration, iconography, print |
| 4 | **brand** | Brand strategy, identity, guidelines |
| 5 | **motion** | Animation, micro-interactions, Lottie, Framer Motion, GSAP |

Usage: `/hub design <subcategory>`
