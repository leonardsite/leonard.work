# Security Skills

| # | Subcategory | Topics |
|---|------------|--------|
| 1 | **appsec** | OWASP, secure coding, SAST, DAST |
| 2 | **pentest** | Reconnaissance, exploitation, reporting |
| 3 | **cloud-sec** | AWS security, zero-trust, IAM, secrets |
| 4 | **grc** | ISO 27001, SOC2, GDPR, risk assessment |
| 5 | **devsecops** | Supply chain, SBOM, container scanning |

Usage: `/hub security <subcategory>`
