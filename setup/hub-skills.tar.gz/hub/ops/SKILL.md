# Ops Skills

| # | Subcategory | Topics |
|---|------------|--------|
| 1 | **signing** | PDF 签名, 手写签名处理 |
| 2 | **cloudflare** | Workers, KV, R2, D1, API token 管理 |
| 3 | **mcp** | MCP server 添加/移除/列表 |

Usage: `/hub ops <subcategory>`
