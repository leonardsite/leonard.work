---
name: sign-pdf
description: "PDF签字机器人 - 将手写签名图片去白底、生成多个随机变体，自动识别PDF签名位置并批量签名。用户说'签字'、'签名'、'sign pdf'时触发。仅限本地使用。"
version: 1.0.0
disable-model-invocation: true
---

# PDF 签字机器人

自动化 PDF 文件批量签名工具。将手写签名图片处理为透明 PNG，生成多个随机变体（拉伸/压缩不超过20%），自动识别 PDF 中的签名位置，批量放置签名。

## 使用方式

```
/sign-pdf <签名图片路径> <PDF文件或目录路径>
```

**参数说明：**
- `签名图片路径`：手写签名的图片文件（PNG/JPG），白底黑字
- `PDF文件或目录路径`：单个 PDF 文件，或包含多个 PDF 的目录

## 工作流程

### Step 1: 环境准备

运行 `scripts/setup_env.sh` 创建 Python 虚拟环境并安装依赖（Pillow, PyMuPDF, numpy）。如果虚拟环境已存在则跳过。

### Step 2: 签名处理

运行签名处理脚本，传入签名图片路径：

```bash
source /tmp/sign-pdf-venv/bin/activate && python3 ~/.claude/skills/sign-pdf/scripts/process_signature.py <签名图片路径> <输出目录>
```

该脚本会：
1. 去除白色/近白色背景，生成透明 PNG
2. 自动裁剪到签名内容边界
3. 生成 8 个随机变体（宽度和高度各自在 ±20% 范围内随机缩放）
4. 输出到 `<输出目录>/signatures/` 下

### Step 3: 分析 PDF 签名位置

运行签名位置分析脚本：

```bash
source /tmp/sign-pdf-venv/bin/activate && python3 ~/.claude/skills/sign-pdf/scripts/analyze_pdf.py <PDF路径>
```

该脚本会：
1. 扫描 PDF 中的签名关键词（签署、签名、签章、盖章、sign、signature 等）
2. 获取关键词的精确坐标（x0, y0, x1, y1）
3. 同时获取相邻的"姓名"、"职务"等标签位置，用于确定签名区域的上下边界
4. 输出 JSON 格式的签名位置信息

### Step 4: 确认签名位置

**必须执行：** 将 PDF 渲染为图片（2x 分辨率），用 Read 工具查看，人工确认签名应放置的精确坐标。

签名放置原则：
- 签名底部不得超过"签署：___"下划线以下的"姓名："行顶部
- 签名左侧从"签署：" / "签名：" 标签右侧开始
- 签名大小根据可用空间调整（典型值：100x25pt）
- 每份签名加入 ±2pt 的随机偏移，模拟自然书写

### Step 5: 批量签名

运行批量签名脚本：

```bash
source /tmp/sign-pdf-venv/bin/activate && python3 ~/.claude/skills/sign-pdf/scripts/sign_pdf.py \
  --signatures <签名目录> \
  --pdf <PDF路径> \
  --output <输出目录> \
  --rect "x0,y0,x1,y1" \
  --copies <份数>
```

参数：
- `--signatures`：签名变体目录
- `--pdf`：要签名的 PDF 文件
- `--output`：输出目录
- `--rect`：签名放置区域（PDF 坐标，单位 pt）
- `--copies`：生成份数
- `--prefix`：输出文件名前缀（可选）

### Step 6: 验证（可选）

如果系统安装了 `gemini` CLI，用它逐个检查签名位置：

```bash
cd <输出预览目录> && gemini -p "查看 <图片文件名>。已签名法律文件，检查签名位置是否正确，是否遮挡文字。简洁回答通过/不通过。" --sandbox false -m gemini-2.5-pro -o text
```

### Step 7: 打包

将所有签名后的 PDF 打包为 zip：

```bash
cd <工作目录> && zip -j "已签名文件.zip" <输出目录>/*.pdf
```

## 注意事项

- **仅限本地使用**，不会上传任何文件到外部服务
- 签名图片和生成的变体仅保存在本地
- 如果 PDF 文件名中包含份数信息（如"【20份】"），自动解析为生成份数
- 对于不同布局的 PDF，签名位置需要逐个确认，不要盲目套用
- 签名区域必须避开"姓名："、"职务："等标签文字
