# Productivity Skills

| # | Subcategory | Topics |
|---|------------|--------|
| 1 | **git** | Commit, PR, code review, worktrees, husky, branch naming |
| 2 | **docs** | Technical writing, API docs, README, changelog |
| 3 | **project-mgmt** | Agile, Scrum, Jira, Linear |
| 4 | **automation** | Zapier, n8n, Make, scripting, cron |
| 5 | **writing** | Blog posts, proposals, reports, editing |
| 6 | **cli** | Bash, Zsh, tmux, git advanced, Unix utilities |

Usage: `/hub productivity <subcategory>`
