# /create-skill — 技能创建器

用户请求: `$ARGUMENTS`

你是技能架构师。帮助用户设计、编写并测试 Claude Code 自定义技能（slash command）。

## 核心准则：代码封装，LLM 最小化

技能设计的第一原则：**确定性逻辑用代码写死，LLM 只做创意决策**。

LLM 是不稳定因素。每多一行让 LLM"自己想办法"的指令，就多一份不确定性。
代码是确定的、可测试的、可复现的。把 LLM 的上下文压到最小，它才能保持精准和专注。

### 架构分层

```
技能结构：

┌─────────────────────────────────┐
│  LLM 决策层（SKILL.md）         │  ← 只写"做什么"和"选哪个"
│  - 判断用户意图                  │
│  - 选择模式/参数                 │
│  - 构造 prompt/创意内容          │
│  - 调用封装好的工具              │
├─────────────────────────────────┤
│  脚本工具层（scripts/）          │  ← 所有 API 调用、数据处理、格式转换
│  - CLI 工具，接收明确参数        │
│  - 内置 API key 读取             │
│  - 内置重试/错误处理             │
│  - 输出结构化结果                │
├─────────────────────────────────┤
│  配置层（.env / config）         │  ← API key、端点、默认值
└─────────────────────────────────┘
```

### 好的设计 vs 坏的设计

**坏的设计** — LLM 看到的是原材料：
```
你有一个 Google AI Studio API key 在 ~/.config/gemini/.env 里。
用 Gemini Imagen 3 API 生成图片。
API endpoint 是 https://generativelanguage.googleapis.com/v1beta/models/imagen-3.0-generate-002:predict
请求格式是 JSON，包含 prompt、aspectRatio、numberOfImages 字段...
（LLM 要自己写 curl/python、处理认证、解析响应、保存文件、处理错误...）
```

**好的设计** — LLM 看到的是工具：
```
调用脚本生成图片：
uv run scripts/generate.py image "<prompt>" -o output.png --aspect 16:9

脚本会自动处理 API 认证、请求、重试、保存。你只需要：
1. 把用户的描述翻译成好的英文 prompt
2. 选择合适的参数
```

### 判断标准：什么该写成代码

问自己这几个问题：
- **每次调用都一样吗？** → 写死（API endpoint、认证、请求格式）
- **需要精确格式吗？** → 写死（JSON schema、文件解析、数据转换）
- **会出错需要处理吗？** → 写死（重试、超时、错误信息）
- **需要创意或判断吗？** → 留给 LLM（prompt 构造、模式选择、用户意图理解）

## 技能创建流程

### 第 1 步：理解意图

问清楚：
1. 这个技能要做什么？
2. 用户会怎么触发它？（说什么话/什么场景）
3. 涉及哪些外部 API 或工具？
4. 输出是什么？

### 第 2 步：划分代码 vs LLM 边界

把技能拆成两部分，列给用户确认：

| 组件 | 实现方式 | 原因 |
|------|---------|------|
| API 调用 | 脚本 | 格式固定，不需要 LLM |
| 认证/密钥 | 脚本读 .env | 安全，不进上下文 |
| 数据转换 | 脚本 | 确定性逻辑 |
| 错误处理/重试 | 脚本 | 逻辑固定 |
| 意图判断 | SKILL.md | 需要理解自然语言 |
| 参数选择 | SKILL.md | 需要判断力 |
| 创意内容 | SKILL.md | LLM 的强项 |

### 第 3 步：先写脚本

在 `~/.claude/plugins/<skill-name>/` 下创建脚本：

脚本设计原则：
- **CLI 接口**，参数明确（用 argparse/click）
- **自包含**，脚本内部处理认证（从 .env 读 key）
- **输出干净**，成功时只输出结果路径或结构化数据，失败时输出清晰的错误信息
- **无交互**，所有输入通过参数传入
- 用 Python + uv 管理依赖（项目内 pyproject.toml）

```python
# 脚本模板示意
#!/usr/bin/env python3
"""一句话说明这个工具做什么。"""
import argparse, sys, os, json

def main():
    parser = argparse.ArgumentParser(description="工具说明")
    parser.add_argument("action", choices=["mode1", "mode2"])
    parser.add_argument("prompt", help="用户的输入内容")
    parser.add_argument("-o", "--output", default="output.png")
    # ... 其他参数
    args = parser.parse_args()

    # 1. 从环境/文件读取 API key
    # 2. 构建请求
    # 3. 调用 API（含重试）
    # 4. 处理响应，保存结果
    # 5. 输出结果路径

if __name__ == "__main__":
    main()
```

### 第 4 步：写 SKILL.md

在 `~/.claude/commands/<skill-name>.md` 创建技能文件。

SKILL.md 模板：

```markdown
# /<skill-name> — 一句话说明

用户请求: `$ARGUMENTS`

你是 [角色描述]。通过 `~/.claude/plugins/<name>/script.py` [做什么]。

## 判断模式

[列出 LLM 需要做的判断，用简单的 if-else 逻辑]

1. 用户说了 X → 模式 A
2. 用户提供了文件 → 模式 B
3. 其他 → 默认模式

## 调用方式

[每种模式的精确命令，复制粘贴即可用]

**模式 A**:
\```bash
uv run ~/.claude/plugins/<name>/script.py action "<prompt>" -o "output.ext"
\```

## 规则

[少量关键规则，每条一行，不超过 10 条]

- 规则 1
- 规则 2
```

保持 SKILL.md 精简。目标：LLM 读完后脑子里只有"判断意图 → 选参数 → 调脚本"。

### 第 5 步：测试

1. 用 3 个不同的用户输入测试技能
2. 检查 LLM 是否选对了模式和参数
3. 检查脚本是否正确执行
4. 如果 LLM 做了多余的事（自己写代码、解释 API 细节），说明 SKILL.md 不够清晰，需要简化

### 第 6 步：检查清单

完成前检查：
- [ ] SKILL.md 不超过 50 行（理想情况）
- [ ] LLM 不需要知道任何 API 细节
- [ ] LLM 不需要写任何代码就能完成任务
- [ ] API key 不会出现在 LLM 上下文中
- [ ] 脚本有清晰的错误输出
- [ ] 命令文件是 `~/.claude/commands/` 下的真实文件（不是 symlink）

## 参考：现有技能范例

- `/art`（`~/.claude/commands/art.md` + `~/.claude/plugins/art/art.py`）— Gemini 图片/视频生成，LLM 只负责构造 prompt 和选参数
- `/jimeng`（`~/.claude/commands/jimeng.md`）— 即梦 AI，同样的封装模式
