---
name: sign
description: Sign PDF documents with Leonard's signature, name, title and date. Stamps handwritten signature + "Leonard Chow Yi Ding" + title + date onto PDF signature pages.
user_invocable: true
---

# PDF Signature Stamping Skill

Sign PDF documents with Leonard Chow Yi Ding's signature using handwriting font and pre-saved signature images.

## Assets Location
- Font: `~/.claude/skills/sign/assets/Caveat.ttf` (handwriting font)
- Signatures (4 variants, transparent PNG):
  - `~/.claude/skills/sign/assets/signature_leonard_2026-03-28.png`
  - `~/.claude/skills/sign/assets/signature_leonard_2026-03-28 (1).png`
  - `~/.claude/skills/sign/assets/signature_leonard_2026-03-28 (2).png`
  - `~/.claude/skills/sign/assets/signature_leonard_2026-03-28 (3).png`

## Usage
When the user invokes `/sign`, follow these steps:

### 1. Ask for inputs (if not provided):
- **PDF files**: path(s) to the PDF(s) to sign
- **Signer name**: default "Leonard Chow Yi Ding"
- **Title/Position**: e.g. "Director", "授权代表" (ask user)
- **Date**: default to today's date in format "DD Month YYYY"
- **Signature position**: ask which field to sign on (签署/signature line), or auto-detect "签署：" text

### 2. Process each PDF:
Use the following Python script pattern to stamp signatures:

```python
import os, random
from PIL import Image
from PyPDF2 import PdfReader, PdfWriter
from reportlab.pdfgen import canvas as rl_canvas
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from io import BytesIO

# Register handwriting font
FONT_PATH = os.path.expanduser("~/.claude/skills/sign/assets/Caveat.ttf")
pdfmetrics.registerFont(TTFont('Caveat', FONT_PATH))

# Signature images (rotate through them)
ASSETS_DIR = os.path.expanduser("~/.claude/skills/sign/assets")
SIG_ORIGINALS = [
    os.path.join(ASSETS_DIR, "signature_leonard_2026-03-28.png"),
    os.path.join(ASSETS_DIR, "signature_leonard_2026-03-28 (1).png"),
    os.path.join(ASSETS_DIR, "signature_leonard_2026-03-28 (2).png"),
    os.path.join(ASSETS_DIR, "signature_leonard_2026-03-28 (3).png"),
]

# Prepare transparent versions (remove white background)
def make_transparent(img_path):
    img = Image.open(img_path).convert("RGBA")
    data = list(img.getdata())
    new_data = [(255,255,255,0) if (r>220 and g>220 and b>220) else (r,g,b,a) for r,g,b,a in data]
    img.putdata(new_data)
    return img

# Ink color (dark blue ballpoint)
INK_RGB = (0.102, 0.227, 0.420)  # #1a3a6b
```

### 3. Signature placement rules:
- **Signature image**: ~55x55pt, placed on the "签署：___" line, right after the colon
- **Name text**: "Leonard Chow Yi Ding" in Caveat font ~13pt, on the "姓名：" line after colon
- **Title text**: user-specified title in Caveat font ~13pt, on the "职务：" line after colon (skip if pre-filled)
- **Date text**: in Caveat font ~12pt, below the last field
- **Ink color**: dark blue (#1a3a6b) for handwriting feel

### 4. Natural variation (IMPORTANT):
To make each signed page look naturally different:
- Rotate through the 4 different signature images
- Apply ~10% width/height variation per file: e.g. (1.0,1.0), (1.08,0.95), (0.92,1.05), (1.05,0.93), (0.94,1.07)
- Add ±2pt random position offset
- Apply ±1.5° slight rotation to handwritten text
- Vary font size by ±0.5pt

### 5. Output:
- Save signed PDFs to user-specified location or same directory with "已签署_" prefix
- Report which files were signed

## Notes
- Always read the PDF first to understand the layout and locate 签署/姓名/职务 fields
- PDF y-coordinates are from bottom-left origin
- Use `mask='auto'` when drawing transparent PNG images with reportlab
- The handwritten text should look like ballpoint pen (dark blue color)
- Dependencies: `PyPDF2`, `reportlab`, `Pillow`
